package com.example.assignment.activity

class Hero( var Name:String,
            var Floor:String,
            var Mobile:String,
            var Address:String,
            var States:String)
