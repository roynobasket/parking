package com.example.assignment.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import com.example.assignment.R
import com.google.firebase.database.FirebaseDatabase

class RegisterActivity : AppCompatActivity() {

    lateinit var Name:String
    lateinit var Floor:String
    lateinit var Mobile:String
    lateinit var Address:String
    lateinit var btnLogin: Button
    lateinit var atv:AutoCompleteTextView
    val states = arrayListOf("Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jammu and Kashmir", "Jharkhand", "Karnataka",
                             "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana",
                             "Tripura", "Uttarakhand", "Uttar Pradesh", "West Bengal", "Andaman and Nicobar Islands", "Chandigarh", "Dadra and Nagar Haveli", "Daman and Diu", "Delhi",
                             "Lakshadweep", "Puducherry")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        Name = findViewById(R.id.etName)
        Floor = findViewById(R.id.etFloors)
        Mobile = findViewById(R.id.etMobile)
        Address = findViewById(R.id.etAddress)
        atv = findViewById(R.id.etState)
        atv.setAdapter(ArrayAdapter<String>(this@RegisterActivity, R.layout.support_simple_spinner_dropdown_item,states))
        btnLogin.setOnClickListener{
            saveHero()
        }
    }

    private fun saveHero() {
        val name = Name.toString().trim()
        val floor = this.Floor.toString().trim()
        val mobile = this.Mobile.toString().trim()
        val address= this.Address.toString().trim()
        val states= this.atv.toString().trim()
        if (name.isEmpty() || floor.isEmpty() || mobile.isEmpty() || address.isEmpty()||
            states.isEmpty()){
            val mD = AlertDialog.Builder(this)
                .setTitle("Alert!!!")
                .setMessage("Please Fill Up All Details")
        }

        var ref= FirebaseDatabase.getInstance().getReference("info")
        val ref_1 = Hero(name, floor, mobile, address, states)
        ref.child(mobile).setValue(ref_1).addOnCompleteListener{
            Toast.makeText(applicationContext,"Data Saved Successfully", Toast.LENGTH_LONG).show()
        }
    }
    }




//
//        etName = findViewById(R.id.etName)
//        etEmail = findViewById(R.id.etEmail)
//        etMobile = findViewById(R.id.etMobile)
//        etAddress = findViewById(R.id.etAddress)
//        etRegisterPassword = findViewById(R.id.etRegisterPassword)
//        etConfirmPassword = findViewById(R.id.etConfirmPassword)
//        btnLogin = findViewById(R.id.btnLogin)
//
//        sharedPreferences = getSharedPreferences(getString(R.string.preference_file_name),Context.MODE_PRIVATE)
//
//        btnLogin.setOnClickListener {
//            if (etName.text.toString().length < 3)
//                Toast.makeText(this@RegisterActivity,"Name is too short", Toast.LENGTH_SHORT).show()
//
//            else if (!(etEmail.text.toString().contains('@')) && !(etEmail.text.toString().contains('.')))
//                Toast.makeText(this@RegisterActivity,"Invalid Email", Toast.LENGTH_SHORT).show()
//
//            else if (etMobile.text.length !=10)
//                Toast.makeText(this@RegisterActivity,"Invalid Phone", Toast.LENGTH_SHORT).show()
//
//            else if (etRegisterPassword.text.toString()==etConfirmPassword.text.toString() && etConfirmPassword.text.toString().isNotEmpty())
//            {
//                sharedPreferences.edit().putBoolean("isLoggedIn",true).apply()
//                sharedPreferences.edit().putString("etName", etName.text.toString()).apply()
//                sharedPreferences.edit().putString("etEmail", etEmail.text.toString()).apply()
//                sharedPreferences.edit().putString("etMobile", etMobile.text.toString()).apply()
//                sharedPreferences.edit().putString("etAddress", etAddress.text.toString()).apply()
//                sharedPreferences.edit().putString("etPassword", etRegisterPassword.text.toString()).apply()
//                val intent = Intent(this@RegisterActivity,HomeActivity::class.java)
//                startActivity(intent)
//                super.onPause()
//                finish()
//            }
//            else
//                Toast.makeText(this@RegisterActivity,"Password Not match", Toast.LENGTH_SHORT).show()
//        }
